﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EpupilSplashScreen
{
    public partial class FormSignUp : Form
    {
        StaffClass staff = new StaffClass();

        public FormSignUp()
        {
            InitializeComponent();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void FormSignUp_MouseHover(object sender, EventArgs e)
        {
            

        }

        private void signsaveb_MouseHover(object sender, EventArgs e)
        {
            
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void FormSignUp_Load(object sender, EventArgs e)
        {
            showTable();
        }


        public void showTable()
        {
              DataGridViewStaff.DataSource = staff.getstafflist();
        }




        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)         //to add details to the databse 
        {

            { string at = radioButton1staff.Checked? "staff" : "admin";
                string first = textBox1fn.Text;
                string last = textBox2ln.Text;
                DateTime sbdate = dateTimePicker1cal.Value;
                string phone = textBox3phn.Text;
                string saddress = textBox8address.Text;
                string desig = textBox1desi.Text;
                string rnumber = textBox11rn.Text;


                if (verify())
                {
                    {
                        if (staff.insertstaff(rnumber,at, first, last, sbdate, phone, saddress, desig))

                        {
                            showTable();
                            MessageBox.Show("New Staff Added", "Add Staff", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }

                else
                {
                    MessageBox.Show("Empty Field", "Add Staff", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }

         }
            //to verify
            bool verify()
            {
                if ((textBox1fn.Text == "") || (textBox2ln.Text == "") ||
                (textBox3phn.Text == "") || (textBox8address.Text== "") ||
                (textBox11rn.Text == ""))
                {
                    return false;
                }
                else
                    return true;
            }

        

        private void dateTimePicker1cal_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //delete

            textBox1fn.Clear();
            textBox2ln.Clear();
            dateTimePicker1cal.Value = DateTime.Now;
            textBox3phn.Clear();
            textBox8address.Clear();
            textBox1desi.Clear();
            textBox11rn.Clear();

        }

        private void textBox1fn_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2ln_TextChanged(object sender, EventArgs e)
        {

        }

        //to edite staff details 
        private void button3_Click(object sender, EventArgs e)// update staff details 
        {

            
                string at = radioButton1staff.Checked ? "staff" : "admin";
                string first = textBox1fn.Text;
                string last = textBox2ln.Text;
                DateTime sbdate = dateTimePicker1cal.Value;
                string phone = textBox3phn.Text;
                string saddress = textBox8address.Text;
                string desig = textBox1desi.Text;
                string rnumber = textBox11rn.Text;


                if (verify())
                {
                    {
                        if (staff.insertstaff(rnumber, at, first, last, sbdate, phone, saddress, desig))

                        {
                            showTable();
                            MessageBox.Show("Staff Updated", "Add Staff", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }

                else
                {
                    MessageBox.Show("Empty Field", "Update Staff", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            DataGridViewStaff.DataSource = staff.searchstaff(textBox4search.Text);
        }

        private void DataGridViewStaff_Click(object sender, EventArgs e)
        {

                if (DataGridViewStaff.CurrentRow.Cells[2].Value.ToString() == "Staff") radioButton1staff.Checked = true; radioButton2admin.Checked = true;

                textBox11rn.Text = DataGridViewStaff.CurrentRow.Cells[1].Value.ToString();
                textBox1fn.Text = DataGridViewStaff.CurrentRow.Cells[3].Value.ToString();
                textBox2ln.Text = DataGridViewStaff.CurrentRow.Cells[4].Value.ToString();
                dateTimePicker1cal.Value= (DateTime)DataGridViewStaff.CurrentRow.Cells[5].Value;
                textBox3phn.Text = DataGridViewStaff.CurrentRow.Cells[6].Value.ToString();
                textBox8address.Text = DataGridViewStaff.CurrentRow.Cells[7].Value.ToString();
                textBox1desi.Text = DataGridViewStaff.CurrentRow.Cells[8].Value.ToString();
                
        }

        //to delete students 
        private void button4_Click(object sender, EventArgs e)
        {
             string rnumber = textBox11rn.Text;

            //Show a confirmation message before delete the staff
            if (MessageBox.Show("want to remove this staff", "Remove staff", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (staff.deletestaff(rnumber))
                {
                    showTable();
                    MessageBox.Show("Staff Removed", "Remove staff", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
            }
        }

        private void button5test_Click(object sender, EventArgs e)
        {
            
        }
    }
}
