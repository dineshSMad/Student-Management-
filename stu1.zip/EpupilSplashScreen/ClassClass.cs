﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;

namespace EpupilSplashScreen
{
    class ClassClass
    {
        DBconnect connect = new DBconnect();

        public bool insertclass(string ClassN, string ClassName, string Seat, string AC)
        {
            MySqlCommand command = new MySqlCommand("INSERT INTO `class`(`ClassN`, `ClassName`, `Seat`, `A/C`) VALUES (@cn, @cname, @seat, @ac)", connect.getconnection);

            command.Parameters.Add("@cn", MySqlDbType.VarChar).Value = ClassN;
            command.Parameters.Add("@cname", MySqlDbType.VarChar).Value = ClassName;
            command.Parameters.Add("@seat", MySqlDbType.VarChar).Value = Seat;
            command.Parameters.Add("@ac", MySqlDbType.VarChar).Value = AC;


            connect.openConnect();
            if (command.ExecuteNonQuery() == 1)
            {
                connect.closeconnect();
                return true;
            }
            else
            {
                connect.closeconnect();
                return false;
            }
        }

        public bool updateclass(string ClassN, string ClassName, string Seat, string AC)
        {
            MySqlCommand command = new MySqlCommand("UPDATE INTO `class` SET  `ClassName`=@cname, `Seat`=@seat, `A/C`=@ac WHERE `ClassN`=@cn", connect.getconnection);

            command.Parameters.Add("@cn", MySqlDbType.VarChar).Value = ClassN;
            command.Parameters.Add("@cname", MySqlDbType.VarChar).Value = ClassName;
            command.Parameters.Add("@seat", MySqlDbType.VarChar).Value = Seat;
            command.Parameters.Add("@ac", MySqlDbType.VarChar).Value = AC;


            connect.openConnect();
            if (command.ExecuteNonQuery() == 1)
            {
                connect.closeconnect();
                return true;
            }
            else
            {
                connect.closeconnect();
                return false;
            }
        }

        public bool deleteclass(string ClassN)
        {
            MySqlCommand command = new MySqlCommand("DELETE FROM `class` WHERE `ClassN`=@cn", connect.getconnection);


            command.Parameters.Add("@cn", MySqlDbType.VarChar).Value = ClassN;
           

            connect.openConnect();
            if (command.ExecuteNonQuery() == 1)
            {
                connect.closeconnect();
                return true;
            }
            else
            {
                connect.closeconnect();
                return false;
            }
        }
        //table
        public DataTable getClasslist()
       {
       MySqlCommand command = new MySqlCommand("SELECT * FROM `class`", connect.getconnection);
       MySqlDataAdapter adapter = new MySqlDataAdapter(command);
       DataTable table = new DataTable();
       adapter.Fill(table);
       return table;
        }

        // for the combo box
        public DataTable getClasslistforcombo(MySqlCommand command)
        {

            command.Connection = connect.getconnection;
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }








    }
}
