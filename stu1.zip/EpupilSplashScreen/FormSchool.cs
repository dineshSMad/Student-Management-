﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EpupilSplashScreen
{
    public partial class FormSchool : Form
    {
        SchoolClass oneschool = new SchoolClass();
        RegisteredStudentClass student = new RegisteredStudentClass();

        public FormSchool()
        {
            InitializeComponent();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormSchool_Load(object sender, EventArgs e)
        {
            showTable();
            studentCount();//to diaplay the number of students 




        }

        private void button2_Click(object sender, EventArgs e)     //delete Button
        {
            
           textBox1SchoolName.Clear();         
           textBox2RegiN.Clear();
           textDean.Clear(); 
          

        }

        public void showTable()
        {
            DataGridViewSchool.DataSource = oneschool.getschoollist();
        }


        private void button1_Click(object sender, EventArgs e)//to addd school details 
        {
                string Scname = textBox1SchoolName.Text;
                string Scnumber = textBox2RegiN.Text;
                string DeanN = textDean.Text;
                

                if (verify())
                {
                    {
                        if (oneschool.insertschool(Scname, Scnumber, DeanN))

                        {
                            showTable();
                            MessageBox.Show("New School Added", "Add School", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }

                }

                else
                {
                    MessageBox.Show("Empty Field", "Add School", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }


                //to verify
                bool verify()
                {
                    if ((textBox1SchoolName.Text == "") || (textBox2RegiN.Text == "") ||
                    (textDean.Text == ""))
                    {
                        return false;
                    }
                    else
                        return true;
                }
        }

           private void studentCount()
            {
                label6.Text = " " + student.totalStudent();//Display the values   

            }private void label6_Click(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)//To Edite 
        {
                string Scname = textBox1SchoolName.Text;
                string Scnumber = textBox2RegiN.Text;
                string DeanN = textDean.Text;


                if (verify())
                {
                    {
                        if (oneschool.insertschool(Scname, Scnumber, DeanN))

                        {
                            showTable();
                            MessageBox.Show("School Details Edited", "Edite School", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }

                }

                else
                {
                    MessageBox.Show("Empty Field", "Edite School", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }


                //to verify
                bool verify()
                {
                    if ((textBox1SchoolName.Text == "") || (textBox2RegiN.Text == "") ||
                    (textDean.Text == ""))
                    {
                        return false;
                    }
                    else
                        return true;
                }
           
        }

        private void DataGridViewSchool_Click(object sender, EventArgs e)
        {
            textBox1SchoolName.Text= DataGridViewSchool.CurrentRow.Cells[0].Value.ToString();
            textBox2RegiN.Text= DataGridViewSchool.CurrentRow.Cells[1].Value.ToString();
            textDean.Text= DataGridViewSchool.CurrentRow.Cells[2].Value.ToString();

        }
    }
}
