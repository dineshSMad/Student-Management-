﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;

namespace EpupilSplashScreen
{
    class studentclassClass
    {
        DBconnect connect = new DBconnect();

        public bool insertsch(string name1, DateTime dot, string su, string ti, string cl)
        {
            MySqlCommand command = new MySqlCommand("INSERT INTO `mapstudentclass`(`FName`, `Date`, `Subject`, `Time`, `Class`) VALUES (@na1, @da, @su, @ti, @cl)", connect.getconnection);

            command.Parameters.Add("@na1", MySqlDbType.VarChar).Value = name1;
            command.Parameters.Add("@da", MySqlDbType.Date).Value = dot;
            command.Parameters.Add("@su", MySqlDbType.VarChar).Value = su;
            command.Parameters.Add("@ti", MySqlDbType.VarChar).Value = ti;
            command.Parameters.Add("@cl", MySqlDbType.VarChar).Value = cl;
           

            connect.openConnect();
            if (command.ExecuteNonQuery() == 1)
            {
                connect.closeconnect();
                return true;
            }
            else
            {
                connect.closeconnect();
                return false;
            }

        }

    

        //to search student (first name, last name)
        public DataTable searchStu(string searchdata)
        {
            MySqlCommand command = new MySqlCommand("SELECT * FROM `mapstudentclass` WHERE CONCAT(`FName`) LIKE '%" + searchdata + "%'", connect.getconnection);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }


        //create a function to edit students
        public bool updatesch(string name1, string name2, DateTime dot, string su,
          string ti, string cl)
        {
            MySqlCommand command = new MySqlCommand("UPDATE INTO `mapstudentclass` SET `Date`= @da, `Subject`=@su, `Time`=@ti,`Class`=cl WHERE `FName`=@na1", connect.getconnection);


            //`FName`, `LName`,`Date`, `Subject`, `Time`, `Class`) VALUES(@na1, @na2, @da, @su, @ti, @cl

            command.Parameters.Add("@na1", MySqlDbType.VarChar).Value = name1;
            command.Parameters.Add("@da", MySqlDbType.Date).Value = dot;
            command.Parameters.Add("@su", MySqlDbType.VarChar).Value = su;
            command.Parameters.Add("@ti", MySqlDbType.VarChar).Value = ti;
            command.Parameters.Add("@cl", MySqlDbType.VarChar).Value = cl;

            connect.openConnect();
            if (command.ExecuteNonQuery() == 1)
            {
                connect.closeconnect();
                return true;
            }
            else
            {
                connect.closeconnect();
                return false;
            }

        }


        //Create a function to delete data 
        public bool deletesch(string name1)
        {
            MySqlCommand command = new MySqlCommand("DELETE FROM `mapstudentclass` WHERE `FName`=@na1", connect.getconnection);

            //@fn
            command.Parameters.Add("@na1", MySqlDbType.VarChar).Value = name1;

            connect.openConnect();
            if (command.ExecuteNonQuery() == 1)
            {
                connect.closeconnect();
                return true;
            }
            else
            {
                connect.closeconnect();
                return false;
            }

        }


        //table
        public DataTable getclasslist()
        {

            MySqlCommand command = new MySqlCommand("SELECT * FROM `mapstudentclass`", connect.getconnection);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }

    }
}
