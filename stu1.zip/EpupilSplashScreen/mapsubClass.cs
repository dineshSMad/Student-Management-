﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;


namespace EpupilSplashScreen
{
    class mapsubClass
    {
        DBconnect connect = new DBconnect();


        public bool insertclass(DateTime dato, string Stsub, string Sttime, string Class) //to insert data to databse 
        {
            MySqlCommand command = new MySqlCommand("INSERT INTO `mapsubclass`( `Date`, `Subject`, `Time`, `Class`) VALUES (@da, @sj, @ti, @cl)", connect.getconnection);

            command.Parameters.Add("@da", MySqlDbType.VarChar).Value = dato;
            command.Parameters.Add("@sj", MySqlDbType.VarChar).Value = Stsub;
            command.Parameters.Add("@ti", MySqlDbType.VarChar).Value = Sttime;
            command.Parameters.Add("@cl", MySqlDbType.VarChar).Value = Class;
            

            connect.openConnect();
            if (command.ExecuteNonQuery() == 1)
            {
                connect.closeconnect();
                return true;
            }
            else
            {
                connect.closeconnect();
                return false;
            }

        }


        public bool editeclass(DateTime dato, string Stsub, string Sttime, string Class) //to insert data to databse 
        {
            MySqlCommand command = new MySqlCommand("UPDATE INTO `mapsubclass`SET `Date`=@da, `Time`= @ti, `Class`=@cl WHERE `Subject`=@sj ", connect.getconnection);

            command.Parameters.Add("@da", MySqlDbType.VarChar).Value = dato;
            command.Parameters.Add("@sj", MySqlDbType.VarChar).Value = Stsub;
            command.Parameters.Add("@ti", MySqlDbType.VarChar).Value = Sttime;
            command.Parameters.Add("@cl", MySqlDbType.VarChar).Value = Class;


            connect.openConnect();
            if (command.ExecuteNonQuery() == 1)
            {
                connect.closeconnect();
                return true;
            }
            else
            {
                connect.closeconnect();
                return false;
            }

        }

        public DataTable searchsul(string searchdata)
        {
            MySqlCommand command = new MySqlCommand("SELECT * FROM `mapsubclass` WHERE CONCAT(`Date`,`Subject`) LIKE '%" + searchdata + "%'", connect.getconnection);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }

        public bool deleteclass(string Sttime)
        {
            MySqlCommand command = new MySqlCommand("DELETE FROM `mapsubclass` WHERE `Subject`=@sj", connect.getconnection);

            //@si
            command.Parameters.Add("@sj", MySqlDbType.VarChar).Value = Sttime;

            connect.openConnect();
            if (command.ExecuteNonQuery() == 1)
            {
                connect.closeconnect();
                return true;
            }
            else
            {
                connect.closeconnect();
                return false;
            }

        }

        //table
        public DataTable getclasslist()
        {

            MySqlCommand command = new MySqlCommand("SELECT * FROM `mapsubclass`", connect.getconnection);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }

    }
}
