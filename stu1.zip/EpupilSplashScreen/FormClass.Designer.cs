﻿
namespace EpupilSplashScreen
{
    partial class FormClass
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormClass));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.button10 = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox6seat = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxClassName = new System.Windows.Forms.TextBox();
            this.button2delete = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button1save = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.airradiobAC = new System.Windows.Forms.RadioButton();
            this.radioButtonnonac = new System.Windows.Forms.RadioButton();
            this.DataGridViewclass = new Guna.UI2.WinForms.Guna2DataGridView();
            this.textBox2Cnum = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridViewclass)).BeginInit();
            this.SuspendLayout();
            // 
            // button10
            // 
            this.button10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button10.BackgroundImage")));
            this.button10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Location = new System.Drawing.Point(993, 848);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(33, 34);
            this.button10.TabIndex = 27;
            this.button10.UseVisualStyleBackColor = true;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(1031, 12);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(33, 33);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 38;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Nirmala UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label6.Location = new System.Drawing.Point(318, 139);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 28);
            this.label6.TabIndex = 90;
            this.label6.Text = "Seats";
            // 
            // textBox6seat
            // 
            this.textBox6seat.Location = new System.Drawing.Point(493, 143);
            this.textBox6seat.Name = "textBox6seat";
            this.textBox6seat.Size = new System.Drawing.Size(210, 26);
            this.textBox6seat.TabIndex = 91;
            this.textBox6seat.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Nirmala UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label7.Location = new System.Drawing.Point(318, 98);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(121, 28);
            this.label7.TabIndex = 93;
            this.label7.Text = "Class Name";
            // 
            // textBoxClassName
            // 
            this.textBoxClassName.Location = new System.Drawing.Point(493, 102);
            this.textBoxClassName.Name = "textBoxClassName";
            this.textBoxClassName.Size = new System.Drawing.Size(210, 26);
            this.textBoxClassName.TabIndex = 94;
            // 
            // button2delete
            // 
            this.button2delete.BackColor = System.Drawing.SystemColors.ControlLight;
            this.button2delete.Font = new System.Drawing.Font("Nirmala UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2delete.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button2delete.Location = new System.Drawing.Point(802, 337);
            this.button2delete.Name = "button2delete";
            this.button2delete.Size = new System.Drawing.Size(116, 36);
            this.button2delete.TabIndex = 98;
            this.button2delete.Text = "CLEAR";
            this.button2delete.UseVisualStyleBackColor = false;
            this.button2delete.Click += new System.EventHandler(this.button2delete_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.button3.Font = new System.Drawing.Font("Nirmala UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button3.Location = new System.Drawing.Point(350, 337);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(116, 36);
            this.button3.TabIndex = 97;
            this.button3.Text = "EDITE";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1save
            // 
            this.button1save.BackColor = System.Drawing.SystemColors.ControlLight;
            this.button1save.Font = new System.Drawing.Font("Nirmala UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1save.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button1save.Location = new System.Drawing.Point(124, 337);
            this.button1save.Name = "button1save";
            this.button1save.Size = new System.Drawing.Size(116, 36);
            this.button1save.TabIndex = 96;
            this.button1save.Text = "SAVE";
            this.button1save.UseVisualStyleBackColor = false;
            this.button1save.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Nirmala UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label2.Location = new System.Drawing.Point(318, 191);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(139, 25);
            this.label2.TabIndex = 100;
            this.label2.Text = "A/C -  Non A/C";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // airradiobAC
            // 
            this.airradiobAC.AutoSize = true;
            this.airradiobAC.Font = new System.Drawing.Font("Nirmala UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.airradiobAC.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.airradiobAC.Location = new System.Drawing.Point(524, 189);
            this.airradiobAC.Name = "airradiobAC";
            this.airradiobAC.Size = new System.Drawing.Size(69, 29);
            this.airradiobAC.TabIndex = 101;
            this.airradiobAC.TabStop = true;
            this.airradiobAC.Text = "A/C";
            this.airradiobAC.UseVisualStyleBackColor = true;
            // 
            // radioButtonnonac
            // 
            this.radioButtonnonac.AutoSize = true;
            this.radioButtonnonac.Font = new System.Drawing.Font("Nirmala UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonnonac.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.radioButtonnonac.Location = new System.Drawing.Point(633, 189);
            this.radioButtonnonac.Name = "radioButtonnonac";
            this.radioButtonnonac.Size = new System.Drawing.Size(116, 29);
            this.radioButtonnonac.TabIndex = 102;
            this.radioButtonnonac.TabStop = true;
            this.radioButtonnonac.Text = "NON A/C";
            this.radioButtonnonac.UseVisualStyleBackColor = true;
            // 
            // DataGridViewclass
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.DataGridViewclass.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DataGridViewclass.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DataGridViewclass.BackgroundColor = System.Drawing.Color.White;
            this.DataGridViewclass.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DataGridViewclass.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DataGridViewclass.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGridViewclass.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.DataGridViewclass.ColumnHeadersHeight = 4;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGridViewclass.DefaultCellStyle = dataGridViewCellStyle3;
            this.DataGridViewclass.EnableHeadersVisualStyles = false;
            this.DataGridViewclass.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.DataGridViewclass.Location = new System.Drawing.Point(27, 412);
            this.DataGridViewclass.Name = "DataGridViewclass";
            this.DataGridViewclass.RowHeadersVisible = false;
            this.DataGridViewclass.RowHeadersWidth = 62;
            this.DataGridViewclass.RowTemplate.Height = 28;
            this.DataGridViewclass.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGridViewclass.Size = new System.Drawing.Size(1026, 402);
            this.DataGridViewclass.TabIndex = 103;
            this.DataGridViewclass.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.DataGridViewclass.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.DataGridViewclass.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.DataGridViewclass.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.DataGridViewclass.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.DataGridViewclass.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.DataGridViewclass.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.DataGridViewclass.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.DataGridViewclass.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DataGridViewclass.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.DataGridViewclass.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.DataGridViewclass.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.DataGridViewclass.ThemeStyle.HeaderStyle.Height = 4;
            this.DataGridViewclass.ThemeStyle.ReadOnly = false;
            this.DataGridViewclass.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.DataGridViewclass.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DataGridViewclass.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.DataGridViewclass.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.DataGridViewclass.ThemeStyle.RowsStyle.Height = 28;
            this.DataGridViewclass.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.DataGridViewclass.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.DataGridViewclass.Click += new System.EventHandler(this.DataGridViewclass_Click);
            // 
            // textBox2Cnum
            // 
            this.textBox2Cnum.Location = new System.Drawing.Point(493, 60);
            this.textBox2Cnum.Name = "textBox2Cnum";
            this.textBox2Cnum.Size = new System.Drawing.Size(210, 26);
            this.textBox2Cnum.TabIndex = 104;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Nirmala UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(321, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 28);
            this.label1.TabIndex = 105;
            this.label1.Text = "Class Number";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.button1.Font = new System.Drawing.Font("Nirmala UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button1.Location = new System.Drawing.Point(576, 337);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(116, 36);
            this.button1.TabIndex = 106;
            this.button1.Text = "DELETE";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // FormClass
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1076, 826);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox2Cnum);
            this.Controls.Add(this.DataGridViewclass);
            this.Controls.Add(this.radioButtonnonac);
            this.Controls.Add(this.airradiobAC);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button2delete);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button1save);
            this.Controls.Add(this.textBoxClassName);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBox6seat);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.button10);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormClass";
            this.Text = "FormClass";
            this.Load += new System.EventHandler(this.FormClass_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridViewclass)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox6seat;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxClassName;
        private System.Windows.Forms.Button button2delete;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1save;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton airradiobAC;
        private System.Windows.Forms.RadioButton radioButtonnonac;
        private Guna.UI2.WinForms.Guna2DataGridView DataGridViewclass;
        private System.Windows.Forms.TextBox textBox2Cnum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
    }
}