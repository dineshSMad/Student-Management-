﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;

namespace EpupilSplashScreen
{
    class SchoolClass
    {
        SchoolDb connect = new SchoolDb();

        public bool insertschool(string Sname, string Snumber, string Dean)
        {
            MySqlCommand command = new MySqlCommand("INSERT INTO `school`(`SchoolN`, `SRN`, `Dean`) VALUES (@sch, @rn, @de)", connect.getconnection);

            command.Parameters.Add("@sch", MySqlDbType.VarChar).Value = Sname;
            command.Parameters.Add("@rn", MySqlDbType.VarChar).Value = Snumber;
            command.Parameters.Add("@de", MySqlDbType.VarChar).Value = Dean;
           
            

            connect.openConnect();
            if (command.ExecuteNonQuery() == 1)
            {
                connect.closeconnect();
                return true;
            }
            else
            {
                connect.closeconnect();
                return false;
            }
        }


        public bool updatetschool(string Sname, string Snumber, string Dean)
        {
            MySqlCommand command = new MySqlCommand("UPDATE INTO `school` SET `SRN`= @rn, `Dean`=@de WHERE`SchoolN`=@sch", connect.getconnection);

            command.Parameters.Add("@sch", MySqlDbType.VarChar).Value = Sname;
            command.Parameters.Add("@rn", MySqlDbType.VarChar).Value = Snumber;
            command.Parameters.Add("@de", MySqlDbType.VarChar).Value = Dean;



            connect.openConnect();
            if (command.ExecuteNonQuery() == 1)
            {
                connect.closeconnect();
                return true;
            }
            else
            {
                connect.closeconnect();
                return false;
            }
        }




        //table
        public DataTable getschoollist()
        {

            MySqlCommand command = new MySqlCommand("SELECT * FROM `school`", connect.getconnection);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }



    }
}
