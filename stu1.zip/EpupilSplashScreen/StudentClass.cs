﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace EpupilSplashScreen
{
    public partial class StudentClassNN : Form
    {
        DBconnect connect = new DBconnect();

        studentclassClass sch = new studentclassClass();

        ClassClass cls = new ClassClass();

        RegisteredStudentClass stu = new RegisteredStudentClass();

        SubjectClass sub = new SubjectClass();

        public StudentClassNN()
        {
            InitializeComponent();
        }

        private void StudentClass_Load(object sender, EventArgs e)
        {
            showTable();

            //populate class combobox 
            comboBox2class.DataSource = cls.getClasslistforcombo(new MySqlCommand("SELECT * FROM `class`"));
            comboBox2class.DisplayMember = "ClassName";
            comboBox2class.ValueMember = "ClassName";


            //populate student combobox
            textBox3firstname.DataSource = stu.getStudentlistcombo(new MySqlCommand("SELECT * FROM `student` "));
            textBox3firstname.DisplayMember = "StdFN";
            textBox3firstname.ValueMember = "StdFN";

            comboBox3subject.DataSource = sub.gettocourscombo(new MySqlCommand("SELECT * FROM `course` "));
            comboBox3subject.DisplayMember = "Subject 01";
            comboBox3subject.ValueMember = "Subject 01";



        }

        //student list
        public void showTable()
        {
            DataGridView1.DataSource = sch.getclasslist();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void buttonSave_Click(object sender, EventArgs e) //save data 
        {

            string fname = textBox3firstname.Text;
            DateTime bday = dateTimePicker1.Value;
            string sub1 = comboBox3subject.Text;
            string jok = comboBox1time.Text;
            string cs = comboBox2class.Text;

            if (verify())
            {
                {
                    if (sch.insertsch(fname, bday, sub1, jok, cs))

                    {
                        showTable();
                        MessageBox.Show("New class Added", "Add class", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }

            else
            {
                MessageBox.Show("Empty Field", "Add class", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        bool verify()
        {
            if ((textBox3firstname.Text == "") ||
            (comboBox3subject.Text == "") || (comboBox1time.Text == "") ||
            (comboBox2class.Text == ""))
            {
                return false;
            }
            else
                return true;
        }




        private void buttonEdite_Click(object sender, EventArgs e)
        {

            string fname = textBox3firstname.Text;
            DateTime bday = dateTimePicker1.Value;
            string sub1 = comboBox3subject.Text;
            string jok = comboBox1time.Text;
            string cs = comboBox2class.Text;

            if (verify())
            {
                {
                    if (sch.insertsch(fname, bday, sub1, jok, cs))

                    {
                        showTable();
                        MessageBox.Show("New class Edited", "Edited class", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }

            else
            {
                MessageBox.Show("Empty Field", "Editted class", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void buttonDelete_Click(object sender, EventArgs e) //to clear data
        {
            textBox3firstname.Text = "";
            dateTimePicker1.Value = DateTime.Now;
            comboBox3subject.Text = "";
            comboBox1time.Text = "";
            comboBox2class.Text = "";
        }

        private void DataGridView1_Click(object sender, EventArgs e) // retrive data 
        {

            textBox3firstname.Text = DataGridView1.CurrentRow.Cells[0].Value.ToString();
            dateTimePicker1.Value = (DateTime)DataGridView1.CurrentRow.Cells[1].Value;
            comboBox3subject.Text = DataGridView1.CurrentRow.Cells[2].Value.ToString();
            comboBox1time.Text = DataGridView1.CurrentRow.Cells[3].Value.ToString();
            //comboBox2class.Text= DataGridView1.CurrentRow.Cells[4].Value.ToString();


        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            DataGridView1.DataSource = sch.searchStu(textBox11search.Text);
        }

        private void button1delete_Click(object sender, EventArgs e)  //delete search student 

        { //remove the selected Student            


            string fname = textBox3firstname.Text;

            //Show a confirmation message before delete the student
            if (MessageBox.Show("want to remove this class", "Remove class", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (sch.deletesch(fname))
                {
                    showTable();
                    MessageBox.Show("Class Removed", "Remove class", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
            }

        }

        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

