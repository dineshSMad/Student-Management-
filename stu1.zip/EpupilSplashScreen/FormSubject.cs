﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace EpupilSplashScreen
{
    public partial class FormSubject : Form
    {
        SubjectClass course = new SubjectClass();
        public FormSubject()
        {
            InitializeComponent();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void FormSubject_Load(object sender, EventArgs e)
        {
            showTable();
        }


        public void showTable()
        {
            DataGridViewSubject.DataSource = course.getcourslist();
        }


        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void guna2DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string cur = textBox1cou1.Text;
            string curid = textBox1coursecode.Text;
            string s1 = textBoxS1.Text;
            string e1 = textBox5e1.Text;
            string a1 = textBox9a1.Text;
            string l1 = textBox10l1.Text;
            string lh1 = textBox11ech1.Text;
            string s2 = textBox4s2.Text;
            string e2 = textBox6e2.Text;
            string a2 = textBox8a2.Text;
            string l2 = textBox18l2.Text;
            string lh2 = textBox21h2.Text;



            if (verify())
            {
                {
                    if (course.insertcourse(cur, curid, s1, e1, a1, l1, lh1, s2, e2, a2, l2, lh2))

                    {
                        showTable();
                        MessageBox.Show("New Course Added", "Add Subject", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }

            else
            {
                MessageBox.Show("Empty Field", "Add Subject", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

            //to verify
            bool verify()
            {
                if ((textBox1cou1.Text == "") || (textBox1coursecode.Text == "") ||
                (textBoxS1.Text == "") || (textBox5e1.Text == "") ||
                (textBox9a1.Text == "") ||   (textBox11ech1.Text == " "))
                {
                    return false;
                }
                else
                    return true;
            }

        

        private void textBox1coursecode_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {

            string cur = textBox1cou1.Text;
            string curid = textBox1coursecode.Text;
            string s1 = textBoxS1.Text;
            string e1 = textBox5e1.Text;
            string a1 = textBox9a1.Text;
            string l1 = textBox10l1.Text;
            string lh1 = textBox11ech1.Text;
            string s2 = textBox4s2.Text;
            string e2 = textBox6e2.Text;
            string a2 = textBox8a2.Text;
            string l2 = textBox18l2.Text;
            string lh2 = textBox21h2.Text;



            if (verify())
            {
                {
                    if (course.insertcourse(cur, curid, s1, e1, a1, l1, lh1, s2, e2, a2, l2, lh2))

                    {
                        showTable();
                        MessageBox.Show("New Course updated", "Add Subject", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }

            else
            {
                MessageBox.Show("Empty Field", "Editted Subject", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void button2_Click_1(object sender, EventArgs e) // clear button 
        {
            textBox1cou1.Clear();
            textBox1coursecode.Clear();
            textBoxS1.Clear();
            textBox5e1.Clear();
            textBox9a1.Clear();
            textBox10l1.Clear();
            textBox11ech1.Clear();
            textBox4s2.Clear();
            textBox6e2.Clear();
            textBox8a2.Clear();
            textBox18l2.Clear();
            textBox21h2.Clear();
        }

        private void DataGridViewSubject_Click(object sender, EventArgs e) //retrive data fro data base
        {
            textBox1cou1.Text= DataGridViewSubject.CurrentRow.Cells[0].Value.ToString();
            textBox1coursecode.Text= DataGridViewSubject.CurrentRow.Cells[1].Value.ToString();
            textBoxS1.Text= DataGridViewSubject.CurrentRow.Cells[2].Value.ToString();
            textBox5e1.Text= DataGridViewSubject.CurrentRow.Cells[3].Value.ToString();
            textBox9a1.Text= DataGridViewSubject.CurrentRow.Cells[4].Value.ToString();
            textBox10l1.Text= DataGridViewSubject.CurrentRow.Cells[5].Value.ToString();
            textBox11ech1.Text= DataGridViewSubject.CurrentRow.Cells[6].Value.ToString();
            textBox4s2.Text= DataGridViewSubject.CurrentRow.Cells[7].Value.ToString();
            textBox6e2.Text= DataGridViewSubject.CurrentRow.Cells[8].Value.ToString();
            textBox8a2.Text= DataGridViewSubject.CurrentRow.Cells[9].Value.ToString();
            textBox18l2.Text= DataGridViewSubject.CurrentRow.Cells[10].Value.ToString();
            textBox21h2.Text= DataGridViewSubject.CurrentRow.Cells[11].Value.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {

            //remove the selected Student            
            string fname = textBox1cou1.Text;

                //Show a confirmation message before delete the student
            if (MessageBox.Show("want to remove this student", "Remove Student", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    if (course.deletecourse(fname))
                    {
                        showTable();
                        MessageBox.Show("Student Removed", "Remove student", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                }
            
        }
    }
}
