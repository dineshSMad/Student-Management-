﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EpupilSplashScreen
{
    public partial class FormScreen2 : Form
    {
        public FormScreen2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void staffAccount_Click(object sender, EventArgs e)
        {
            //staff login
            Form2login loginS = new Form2login ();
            loginS.Show();
            this.Hide();
        }

        private void AdminAccount_Click(object sender, EventArgs e)
        {
            //admin login
            adminlogin loginS = new adminlogin();
            loginS.Show();
            this.Hide();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void FormScreen2_Load(object sender, EventArgs e)
        {

        }
    }
}
