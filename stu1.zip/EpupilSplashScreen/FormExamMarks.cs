﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace EpupilSplashScreen
{
    public partial class FormExamMarks : Form
    {
        ExammarksClass marks = new ExammarksClass();

        RegisteredStudentClass stu = new RegisteredStudentClass();

        SubjectClass sub = new SubjectClass();

        public FormExamMarks()
        {
            InitializeComponent();
        }

        private void FormExamMarks_Load(object sender, EventArgs e)
        {
            showTable();


            //populate student combobox
            textBox12RN.DataSource = stu.getStudentlistcombo(new MySqlCommand("SELECT * FROM `student` "));
            textBox12RN.DisplayMember = "StdFN";
            textBox12RN.ValueMember = "StdFN";

           
            
            //populate subject 01
            textBox19s1.DataSource = sub.gettocourscombo(new MySqlCommand("SELECT * FROM `course` "));
            textBox19s1.DisplayMember = "Subject 01";
            textBox19s1.ValueMember = "Subject 01";



            //populate subject 02
           textBox16s2.DataSource = sub.gettocourscombo(new MySqlCommand("SELECT * FROM `course` "));
                 textBox16s2.DisplayMember = "Subject 02";
                  textBox16s2.ValueMember = "Subject 02";

        

        }

        public void showTable()
        {

            DataGridView112.DataSource = marks.getmarkslist();
            
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void guna2DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            //Add
            
            string Rnumer = textBox12RN.Text;
            
            string sub1 = textBox19s1.Text;
            string exa1 = textBox18e1.Text;
            string aaa1 = textBox17a1.Text;
            string sub2 = textBox16s2.Text;
            string exa2 = textBox15e2.Text;
            string aaa2 = textBox14a2.Text;

            if (verify())
            {
                {
                    if (marks.insertmarks(Rnumer,sub1, exa1, aaa1,sub2,exa2, aaa2))

                    {
                        showTable();
                        MessageBox.Show("Marks Added", "Add Marks", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }

            }

            else
            {
                MessageBox.Show("Empty Field", "Add Marks", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            bool verify()
            {
                if ((textBox12RN.Text == "") || (textBox19s1.Text == "") || (textBox18e1.Text == ""))
                {
                    return false;
                }
                else
                    return true;
            }

        }

    private void button2_Click(object sender, EventArgs e)
        {
            //delete
               
            textBox12RN.Text = "";        
            textBox19s1.Text = "";
            textBox18e1.Clear();
            textBox17a1.Clear();
            textBox16s2.Text = "";
            textBox15e2.Clear();
            textBox14a2.Clear();

            
        }

        private void DataGridView112_Click(object sender, EventArgs e)
        {
            
            textBox12RN.Text = DataGridView112.CurrentRow.Cells[0].Value.ToString();         
            textBox19s1.Text = DataGridView112.CurrentRow.Cells[1].Value.ToString();
            textBox18e1.Text = DataGridView112.CurrentRow.Cells[2].Value.ToString();
            textBox17a1.Text = DataGridView112.CurrentRow.Cells[3].Value.ToString();
            textBox16s2.Text = DataGridView112.CurrentRow.Cells[4].Value.ToString();
            textBox15e2.Text = DataGridView112.CurrentRow.Cells[5].Value.ToString();
            textBox14a2.Text = DataGridView112.CurrentRow.Cells[6].Value.ToString();

        }

        private void textBox12RN_SelectedIndexChanged(object sender, EventArgs e)
        {
             
        }
    }
}
