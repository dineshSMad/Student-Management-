﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EpupilSplashScreen
{
    public partial class FormScreen3staff : Form
    {
        private bool isCollapsed;

        RegisteredStudentClass student = new RegisteredStudentClass();
        StaffClass staff = new StaffClass();

        public FormScreen3staff()
        {
            InitializeComponent();
            panel4.Height = button1223.Height;
            panel4.Top = button1223.Top;

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void FormScreen3_Load(object sender, EventArgs e)
        {
            label5date.Text = DateTime.Now.ToShortDateString();
            studentCount();//to diaplay the number of students 
            staffCount();//to diaplay the number of staff
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void studentCount()
        {
            label3student.Text = "Total Students : " + student.totalStudent();//Display the values   
        }

        private void staffCount()
        {


            label6.Text = "Total Staff : " + staff.totalstaff();//Display the values   
        }









        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (isCollapsed)
            {
                panel2.Height += 10;
                if (panel2.Size == panel2.MaximumSize)
                {
                    timer1.Stop();
                    isCollapsed = false;
                }
            }
            else
            {
                panel2.Height -= 10;
                if (panel2.Size == panel2.MinimumSize)
                {
                    timer1.Stop();
                    isCollapsed = true;
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void pictureBox3_Click_1(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click_2(object sender, EventArgs e)
        {
            this.Close();

        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
           // Register form in maiframe 
           private Form activeForm = null;
           private void openChildForm(Form childForm)
            {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            PanelMainsatff.Controls.Add(childForm);
            PanelMainsatff.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }


        private void button4_Click_1(object sender, EventArgs e)
        {
            panel4.Height = button4.Height;
            panel4.Top = button4.Top;
            openChildForm(new MAPSubject());
        }

        private void button5_Click(object sender, EventArgs e)
        {
            panel4.Height = button5.Height;
            panel4.Top = button5.Top;
            openChildForm(new StudentClassNN());
        }

        private void button6_Click(object sender, EventArgs e)
        {
            panel4.Height = button6.Height;
            panel4.Top = button6.Top;
            openChildForm(new FormExamMarks());
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            panel4.Height = button1MR.Height;
            panel4.Top = button1MR.Top;
            openChildForm(new Report());
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            panel4.Height = button3LR.Height;
            panel4.Top = button3LR.Top;
            openChildForm(new FormReport3());
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            panel4.Height = button1223.Height;
            panel4.Top = button1223.Top;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormScreen2 se_form = new FormScreen2();
            se_form.Show();
            this.Close();
        }

        private void label5date_Click(object sender, EventArgs e)
        {
           
        }

        private void PanelMainsatff_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
