﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;

namespace EpupilSplashScreen
{
    class ExammarksClass
    {


        DBconnect connect = new DBconnect();
        
       
        public bool insertmarks(string cname, string sub1, string ex1, string As1, string sub2, string ex2, string As2)
        {
            MySqlCommand command = new MySqlCommand("INSERT INTO `marks`( `RName`, `Subject01`, `Exam01`, `Assignment01`, `Subject02`, `Exam02`, `Assignment02`) VALUES ( @rn, @su1, @ex1, @as1, @su2, @ex2, @as2)", connect.getconnection);

            
            command.Parameters.Add("@rn", MySqlDbType.VarChar).Value = cname;            
            command.Parameters.Add("@su1", MySqlDbType.VarChar).Value = sub1;
            command.Parameters.Add("@ex1", MySqlDbType.VarChar).Value = ex1;
            command.Parameters.Add("@as1", MySqlDbType.VarChar).Value = As1;
            command.Parameters.Add("@su2", MySqlDbType.VarChar).Value = sub2;
            command.Parameters.Add("@ex2", MySqlDbType.VarChar).Value = ex2;
            command.Parameters.Add("@as2", MySqlDbType.VarChar).Value = As2;


            connect.openConnect();
            if (command.ExecuteNonQuery() == 1)
            {
                connect.closeconnect();
                return true;
            }
            else
            {
                connect.closeconnect();
                return false;
            }
        }



        //table
        public DataTable getmarkslist()
        {

            MySqlCommand command = new MySqlCommand("SELECT * FROM `marks`", connect.getconnection);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }

    }

}
