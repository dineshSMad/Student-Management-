﻿
namespace EpupilSplashScreen
{
    partial class FormScreen3staff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormScreen3staff));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button3LR = new System.Windows.Forms.Button();
            this.button1MR = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1223 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.PanelMainsatff = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label3student = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5date = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.button3 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.PanelMainsatff.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Location = new System.Drawing.Point(-1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(406, 850);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel4.Location = new System.Drawing.Point(3, 396);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(13, 72);
            this.panel4.TabIndex = 1;
            // 
            // panel5
            // 
            this.panel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel5.Location = new System.Drawing.Point(0, 816);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(406, 34);
            this.panel5.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button3LR);
            this.panel2.Controls.Add(this.button1MR);
            this.panel2.Controls.Add(this.button8);
            this.panel2.Location = new System.Drawing.Point(3, 630);
            this.panel2.MaximumSize = new System.Drawing.Size(400, 149);
            this.panel2.MinimumSize = new System.Drawing.Size(400, 72);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(400, 72);
            this.panel2.TabIndex = 36;
            // 
            // button3LR
            // 
            this.button3LR.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.button3LR.Dock = System.Windows.Forms.DockStyle.Top;
            this.button3LR.FlatAppearance.BorderSize = 0;
            this.button3LR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3LR.Font = new System.Drawing.Font("Nirmala UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3LR.ForeColor = System.Drawing.Color.White;
            this.button3LR.Location = new System.Drawing.Point(0, 109);
            this.button3LR.Name = "button3LR";
            this.button3LR.Size = new System.Drawing.Size(400, 37);
            this.button3LR.TabIndex = 28;
            this.button3LR.Text = "LOYALTY REPORT";
            this.button3LR.UseVisualStyleBackColor = false;
            this.button3LR.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // button1MR
            // 
            this.button1MR.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.button1MR.Dock = System.Windows.Forms.DockStyle.Top;
            this.button1MR.FlatAppearance.BorderSize = 0;
            this.button1MR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1MR.Font = new System.Drawing.Font("Nirmala UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1MR.ForeColor = System.Drawing.Color.White;
            this.button1MR.Location = new System.Drawing.Point(0, 72);
            this.button1MR.Name = "button1MR";
            this.button1MR.Size = new System.Drawing.Size(400, 37);
            this.button1MR.TabIndex = 26;
            this.button1MR.Text = "MONTHLY INCOME";
            this.button1MR.UseVisualStyleBackColor = false;
            this.button1MR.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.button8.Dock = System.Windows.Forms.DockStyle.Top;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Nirmala UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(0, 0);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(400, 72);
            this.button8.TabIndex = 25;
            this.button8.Text = "GENERATE REPORT";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.pictureBox1);
            this.panel3.Controls.Add(this.button1223);
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(406, 390);
            this.panel3.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.MediumSeaGreen;
            this.label2.Location = new System.Drawing.Point(137, 241);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 38);
            this.label2.TabIndex = 30;
            this.label2.Text = "STAFF";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(89, 31);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(226, 188);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 29;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click_1);
            // 
            // button1223
            // 
            this.button1223.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.button1223.FlatAppearance.BorderSize = 0;
            this.button1223.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1223.Font = new System.Drawing.Font("Nirmala UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1223.ForeColor = System.Drawing.Color.White;
            this.button1223.Location = new System.Drawing.Point(3, 225);
            this.button1223.Name = "button1223";
            this.button1223.Size = new System.Drawing.Size(400, 72);
            this.button1223.TabIndex = 25;
            this.button1223.UseVisualStyleBackColor = false;
            this.button1223.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Nirmala UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(3, 552);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(400, 72);
            this.button6.TabIndex = 24;
            this.button6.Text = "ADD MARKS";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Nirmala UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(0, 474);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(400, 72);
            this.button5.TabIndex = 23;
            this.button5.Text = "MAP STUDENT TO SUBJECT";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Nirmala UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(3, 396);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(400, 72);
            this.button4.TabIndex = 22;
            this.button4.Text = "MAP SUBJECT TO CLASS";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // timer1
            // 
            this.timer1.Interval = 15;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // PanelMainsatff
            // 
            this.PanelMainsatff.BackColor = System.Drawing.Color.Transparent;
            this.PanelMainsatff.BackgroundImage = global::EpupilSplashScreen.Properties.Resources._1388129;
            this.PanelMainsatff.Controls.Add(this.label7);
            this.PanelMainsatff.Controls.Add(this.panel6);
            this.PanelMainsatff.Controls.Add(this.button3);
            this.PanelMainsatff.Controls.Add(this.label5);
            this.PanelMainsatff.Controls.Add(this.label8);
            this.PanelMainsatff.Location = new System.Drawing.Point(405, 3);
            this.PanelMainsatff.Name = "PanelMainsatff";
            this.PanelMainsatff.Size = new System.Drawing.Size(1094, 847);
            this.PanelMainsatff.TabIndex = 4;
            this.PanelMainsatff.Paint += new System.Windows.Forms.PaintEventHandler(this.PanelMainsatff_Paint);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label7.Font = new System.Drawing.Font("Stencil", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label7.Location = new System.Drawing.Point(364, 133);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(597, 47);
            this.label7.TabIndex = 44;
            this.label7.Text = "Student Managemnt System";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.label3student);
            this.panel6.Controls.Add(this.label6);
            this.panel6.Controls.Add(this.label5date);
            this.panel6.Controls.Add(this.pictureBox2);
            this.panel6.Controls.Add(this.pictureBox3);
            this.panel6.Location = new System.Drawing.Point(62, 225);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(957, 446);
            this.panel6.TabIndex = 7;
            // 
            // label3student
            // 
            this.label3student.AutoSize = true;
            this.label3student.BackColor = System.Drawing.Color.Transparent;
            this.label3student.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3student.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3student.ForeColor = System.Drawing.Color.Black;
            this.label3student.Location = new System.Drawing.Point(618, 300);
            this.label3student.Name = "label3student";
            this.label3student.Size = new System.Drawing.Size(253, 32);
            this.label3student.TabIndex = 6;
            this.label3student.Text = "Number of Students ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label6.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(41, 300);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(199, 32);
            this.label6.TabIndex = 7;
            this.label6.Text = "Number of Staff";
            // 
            // label5date
            // 
            this.label5date.AutoSize = true;
            this.label5date.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5date.Font = new System.Drawing.Font("Nirmala UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5date.ForeColor = System.Drawing.Color.White;
            this.label5date.Location = new System.Drawing.Point(416, 17);
            this.label5date.Name = "label5date";
            this.label5date.Size = new System.Drawing.Size(99, 48);
            this.label5date.TabIndex = 5;
            this.label5date.Text = "Date";
            this.label5date.Click += new System.EventHandler(this.label5date_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::EpupilSplashScreen.Properties.Resources.stu1;
            this.pictureBox2.Location = new System.Drawing.Point(624, 186);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(273, 149);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 8;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::EpupilSplashScreen.Properties.Resources.employee1;
            this.pictureBox3.Location = new System.Drawing.Point(47, 186);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(217, 149);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 9;
            this.pictureBox3.TabStop = false;
            // 
            // button3
            // 
            this.button3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button3.BackgroundImage")));
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(1021, 19);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(42, 38);
            this.button3.TabIndex = 47;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.SpringGreen;
            this.label5.Location = new System.Drawing.Point(355, 95);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(381, 38);
            this.label5.TabIndex = 45;
            this.label5.Text = " PUPIL                                 &";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label8.Font = new System.Drawing.Font("Stencil", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label8.Location = new System.Drawing.Point(248, 47);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(157, 171);
            this.label8.TabIndex = 46;
            this.label8.Text = "E";
            // 
            // FormScreen3staff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(1500, 850);
            this.Controls.Add(this.PanelMainsatff);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.Color.SpringGreen;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormScreen3staff";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormScreen3";
            this.Load += new System.EventHandler(this.FormScreen3_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.PanelMainsatff.ResumeLayout(false);
            this.PanelMainsatff.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button3LR;
        private System.Windows.Forms.Button button1MR;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button1223;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label5date;
        private System.Windows.Forms.Panel PanelMainsatff;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label3student;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}