﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EpupilSplashScreen
{
    public partial class FormStudentEdite : Form
    {
        RegisteredStudentClass student = new RegisteredStudentClass();
        public FormStudentEdite()
        {
            InitializeComponent();
        }

        private void FormStudentEdite_Load(object sender, EventArgs e)
        {
            showTable();
        }

        //student list
        public void showTable()
        {
            DataGridViewStudent.DataSource = student.getStudentlist();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {   
            this.Close();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            string fname = textBoxFirstName.Text;
            string lname = textBoxLastName.Text;
            string curs = radioButtoSE.Checked? "male" : "Female";
            DateTime bdate = dateTimePicker10.Value; 
            string year = textBoxYear.Text;
            string address = textBoxAddress.Text;
            string tele = textBoxTp.Text;
            string payment = textBoxPayment.Text;
            string paid = textBoxPaid.Text;
            string due = textBoxDue.Text;
            

              if (verify())
            {
                {
                    if (student.insertStudent(fname, lname, curs, bdate, year, address, tele, payment, paid, due))

                    {
                        showTable();
                        MessageBox.Show("New Student Added", "Add Student", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }  
            }
            
            else
            {
                MessageBox.Show("Empty Field", "Add Student", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }


            //to verify
            bool verify()
            {
                if ((textBoxFirstName.Text == "") || (textBoxLastName.Text == "") ||
                (textBoxTp.Text == "") || (textBoxAddress.Text == "") ||
                (textBoxPayment.Text == "") || (textBoxPayment.Text == "") ||
                (textBoxDue.Text == ""))
                {
                    return false;
                }
                else
                    return true;
            }
        
        //to update or edite the student details 
        private void buttonEdite_Click(object sender, EventArgs e)
        {
            string fname = textBoxFirstName.Text;
            string lname = textBoxLastName.Text;
            string curs = radioButtoSE.Checked ? "male" : "Female";
            DateTime bdate = dateTimePicker10.Value;
            string year = textBoxYear.Text;
            string address = textBoxAddress.Text;
            string tele = textBoxTp.Text;
            string payment = textBoxPayment.Text;
            string paid = textBoxPaid.Text;
            string due = textBoxDue.Text;



            if (verify())
            {
                {
                    if (student.insertStudent(fname, lname, curs, bdate, year, address, tele, payment, paid, due))

                    {
                        showTable();
                        MessageBox.Show(" Student Detail Updated", "Add Student", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }

            else
            {
                MessageBox.Show("Empty Field", "Add Updated", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }
             //clear Button to clean all inputs 
        private void buttonDelete_Click(object sender, EventArgs e)
        {
            textBoxFirstName.Clear();
            textBoxLastName.Clear();
            radioButtoSE.Checked = false;
            dateTimePicker10.Value= DateTime.Now;
            textBoxYear.Clear();
            textBoxAddress.Clear();
            textBoxTp.Clear();
            textBoxPayment.Clear();
            textBoxPaid.Clear();
            textBoxDue.Clear();
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {

        }
       
        //retrieve date from database 
        private void DataGridViewStudent_Click(object sender, EventArgs e)
        {
           textBoxFirstName.Text = DataGridViewStudent.CurrentRow.Cells[1].Value.ToString();
            textBoxLastName.Text = DataGridViewStudent.CurrentRow.Cells[2].Value.ToString();
            if (DataGridViewStudent.CurrentRow.Cells[3].Value.ToString() == "Male") radioButtonManagement.Checked = true; else radioButtoSE.Checked = true;

            dateTimePicker10.Value = (DateTime)DataGridViewStudent.CurrentRow.Cells[7].Value;
            textBoxYear.Text = DataGridViewStudent.CurrentRow.Cells[4].Value.ToString();
            textBoxAddress.Text = DataGridViewStudent.CurrentRow.Cells[6].Value.ToString();
            textBoxTp.Text = DataGridViewStudent.CurrentRow.Cells[5].Value.ToString();
            textBoxPayment.Text = DataGridViewStudent.CurrentRow.Cells[8].Value.ToString();
            textBoxPaid.Text = DataGridViewStudent.CurrentRow.Cells[9].Value.ToString();
            textBoxDue.Text = DataGridViewStudent.CurrentRow.Cells[10].Value.ToString();

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            DataGridViewStudent.DataSource = student.searchStudent(textBox1search.Text);
        }

        private void button123_Click(object sender, EventArgs e)
        {
         
        }

        //to delete student
        private void button1delete_Click(object sender, EventArgs e)
        {

            //remove the selected Student            
                string fname = textBoxFirstName.Text;

            //Show a confirmation message before delete the student
            if (MessageBox.Show("want to remove this student", "Remove Student", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (student.deleteStudent(fname))
                {
                    showTable();
                    MessageBox.Show("Student Removed", "Remove student", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                }
            }
        }
    }
}
