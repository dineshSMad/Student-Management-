﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;

namespace EpupilSplashScreen
{
    class RegisteredStudentClass
    {
        DBconnect connect = new DBconnect();

        public bool insertStudent( string StdFirstName, string StdLastName, string Course, DateTime StuBd, string Year,
           string address, string StdPhone, string Payment, string Paid, string Due)
        {
            MySqlCommand command = new MySqlCommand("INSERT INTO `student`(`StdFN`, `StdLN`, `StdCur`, `DoB`, `StdYer`,`StdAdd`,`StdTP`,  `StdPayment`, `StdPaid`, `StdDue`) VALUES (@fn, @ln, @cur, @dob, @yer, @add, @tp, @payment, @paid, @due)", connect.getconnection);


            //(rnum, fname, lname, curs, bdate, year, address, tele, payment, paid, due))

            command.Parameters.Add("@fn", MySqlDbType.VarChar).Value= StdFirstName;
            command.Parameters.Add("@ln", MySqlDbType.VarChar).Value = StdLastName;
            command.Parameters.Add("@cur", MySqlDbType.VarChar).Value = Course;
            command.Parameters.Add("@dob", MySqlDbType.Date).Value = StuBd;
            command.Parameters.Add("@yer", MySqlDbType.VarChar).Value = Year; 
            command.Parameters.Add("@tp", MySqlDbType.VarChar).Value = StdPhone;
            command.Parameters.Add("@add", MySqlDbType.VarChar).Value = address;
            command.Parameters.Add("@payment", MySqlDbType.VarChar).Value = Payment;
            command.Parameters.Add("@paid", MySqlDbType.VarChar).Value = Paid;
            command.Parameters.Add("@due", MySqlDbType.VarChar).Value = Due;

            connect.openConnect();  
            if (command.ExecuteNonQuery()==1)
            {
                connect.closeconnect();
                return true;
            }
            else
            {
                connect.closeconnect();
                return false;
            }

        }

        // Create a function to execute the count query(total)
        public string Count(string query)
        {
            MySqlCommand command = new MySqlCommand(query, connect.getconnection);
            connect.openConnect();
            string count = command.ExecuteScalar().ToString();
            connect.closeconnect();
            return count;
        }

        // to get the total total students 
        public string totalStudent()
        {
            return Count("SELECT COUNT(*) FROM student");
        }
       
        //to search student (first name, last name)
        public DataTable searchStudent(string searchdata)
        {
            MySqlCommand command = new MySqlCommand("SELECT * FROM `student` WHERE CONCAT(`StdFN`,`StdLN`) LIKE '%" + searchdata + "%'", connect.getconnection);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }


        //create a function edit for student
        public bool updateStudent(string StdFirstName, string StdLastName, string Course, DateTime StuBd, string Year,
          string address, string StdPhone, string Payment, string Paid, string Due)
        {
            MySqlCommand command = new MySqlCommand("UPDATE INTO `student` SET  `StdLN`=@ln, `StdCur`= @cur, `DoB`= @dob, `StdYer`=@yer, `StdAdd`=@add,`StdTP`=@tp,  `StdPayment`=@payment, `StdPaid`=@paid, `StdDue`=@due WHERE `StdFN`=@fn", connect.getconnection);
            //(student.insertStudent(rnum, fname, lname, curs, bdate, year, address, tele, payment, paid, due))

            command.Parameters.Add("@fn", MySqlDbType.VarChar).Value = StdFirstName;
            command.Parameters.Add("@ln", MySqlDbType.VarChar).Value = StdLastName;
            command.Parameters.Add("@cur", MySqlDbType.VarChar).Value = Course;
            command.Parameters.Add("@dob", MySqlDbType.Date).Value = StuBd;
            command.Parameters.Add("@yer", MySqlDbType.VarChar).Value = Year;
            command.Parameters.Add("@tp", MySqlDbType.VarChar).Value = StdPhone;
            command.Parameters.Add("@add", MySqlDbType.VarChar).Value = address;
            command.Parameters.Add("@payment", MySqlDbType.VarChar).Value = Payment;
            command.Parameters.Add("@paid", MySqlDbType.VarChar).Value = Paid;
            command.Parameters.Add("@due", MySqlDbType.VarChar).Value = Due;

            connect.openConnect();
            if (command.ExecuteNonQuery() == 1)
            {
                connect.closeconnect();
                return true;
            }
            else
            {
                connect.closeconnect();
                return false;
            }
        }

        //function to delete data 
        public bool deleteStudent(string StdFirstName)
        {
            MySqlCommand command = new MySqlCommand("DELETE FROM `student` WHERE `StdFN`=@fn", connect.getconnection);

            //@fn
            command.Parameters.Add("@fn", MySqlDbType.VarChar).Value = StdFirstName; 

            connect.openConnect();
            if (command.ExecuteNonQuery() == 1)
            {
                connect.closeconnect();
                return true;
            }
            else
            {
                connect.closeconnect();
                return false;
            }
        }

        //table
        public DataTable getStudentlist()
        {
   
            MySqlCommand command = new MySqlCommand("SELECT * FROM `student`", connect.getconnection);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }

        public DataTable getStudentlistcombo(MySqlCommand command)
        {

            command.Connection = connect.getconnection;
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }

    }
}
