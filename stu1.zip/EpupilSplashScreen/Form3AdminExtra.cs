﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EpupilSplashScreen
{
    public partial class Form3AdminExtra : Form
    {
        RegisteredStudentClass student = new RegisteredStudentClass();
        StaffClass staff = new StaffClass();
       

        public Form3AdminExtra()
        {
            InitializeComponent();
           panel4.Height = button1223admin.Height;
           panel4.Top = button1223admin.Top;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form3AdminExtra_Load(object sender, EventArgs e)
        {

            label5date.Text = DateTime.Now.ToShortDateString();
            studentCount();//to diaplay the number of students 
            staffCount();//to diaplay the number of staff
        }

        // child frame in maiframe 
        private Form activeForm = null;

       
        private void openChildForm(Form childForm)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            PanelMain.Controls.Add(childForm);
            PanelMain.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();

        }

        private void button100_Click(object sender, EventArgs e)
        {     
            //student details 
            openChildForm(new FormStudentEdite());
            panel4.Height = button100.Height;
            panel4.Top = button100.Top;
        }

        private void PanelMain_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button99_Click(object sender, EventArgs e)
        {
            //Class
            panel4.Height = button99.Height;
            panel4.Top = button99.Top;

            openChildForm(new FormClass());


        }

        private void button104_Click(object sender, EventArgs e)
        {
            //school details 
            openChildForm(new FormSchool());
            panel4.Height = button104.Height;
            panel4.Top = button104.Top;
        }

        private void button101_Click(object sender, EventArgs e)
        {
            //staff details 
            openChildForm(new FormSignUp());
            panel4.Height = button101.Height;
            panel4.Top = button101.Top;
        }

        private void button102_Click(object sender, EventArgs e)
        {
            //subject details 

            openChildForm(new FormSubject());
            panel4.Height = button102.Height;
            panel4.Top = button102.Top;
        }

        public void panel4_Paint(object sender, PaintEventArgs e)
        {
            

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1223admin_Click(object sender, EventArgs e)
        {
            panel4.Height = button1223admin.Height;
            panel4.Top = button1223admin.Top;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
        }
        private void studentCount()
        {  
         label3student.Text= "Total Students : " + student.totalStudent();//Display the values   
        }

        private void staffCount()
        {
            
            
            label6.Text = "Total Staff : " + staff.totalstaff();//Display the values   
        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel9_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel10_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormScreen2 se_form = new FormScreen2();
            se_form.Show();
            this.Close();

        }

        private void label5date_Click(object sender, EventArgs e)
        {
           
        }

        private void panel8_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
