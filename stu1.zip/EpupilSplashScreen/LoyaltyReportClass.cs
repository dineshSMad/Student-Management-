﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace EpupilSplashScreen
{
    class LoyaltyReportClass
    {
        DBconnect connect = new DBconnect();

        public void sortCustomers()
        {
            MySqlCommand command = new MySqlCommand("SELECT * FROM `student`", connect.getconnection);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);            
            DataView dv = table.DefaultView;
            dv.Sort = "stdPaid desc";
            DataTable sortedDT = dv.ToTable();
            generateLoyalDoc(sortedDT);
        }

        public void generateLoyalDoc(DataTable dataTable)
        {
            string fileName = @"C:\Users\USER\Desktop\Loyal.txt";

            try
            {
                    
                if (File.Exists(fileName))
                {
                    File.Delete(fileName);
                }

                // Create a new file     
                using (FileStream fs = File.Create(fileName))
                {
                    // Adding text to file
                    foreach (DataRow row in dataTable.Rows)
                    {
                        Byte[] customer = new UTF8Encoding(true).GetBytes(row.Field<String>(1));
                        fs.Write(customer, 0, customer.Length);
                        byte[] colen = new UTF8Encoding(true).GetBytes(":");
                        fs.Write(colen, 0, colen.Length);
                        byte[] stdPaid = new UTF8Encoding(true).GetBytes(row.Field<int>(9).ToString());
                        fs.Write(stdPaid, 0, stdPaid.Length);
                        byte[] newLine = new UTF8Encoding(true).GetBytes("\r\n");
                        fs.Write(newLine, 0, newLine.Length);
                    }

                }

                // Open the stream and read it back.    
                using (StreamReader sr = File.OpenText(fileName))
                {
                    string s = "";
                    while ((s = sr.ReadLine()) != null)
                    {
                        Console.WriteLine(s);
                    }
                }
            }
            catch (Exception Ex)
            {
                Console.WriteLine(Ex.ToString());
            }

        }        
    }
}
