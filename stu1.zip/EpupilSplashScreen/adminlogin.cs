﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using EpupilSplashScreen;

namespace EpupilSplashScreen
{
    public partial class adminlogin : Form
    {
        admindb con = new admindb();
        adminAccountClass acc = new adminAccountClass();

        public adminlogin()
        {
            InitializeComponent();
        }

        private void adminlogin_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //login
            acc.username = textboxusername.Text;
            acc.password = textboxpassword.Text;
            bool verify = acc.validate_user();

            if (verify)
            {
                Form3AdminExtra lo = new Form3AdminExtra();
                lo.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Password or Username is incorrect");
                textboxusername.Clear();
                textboxpassword.Clear();
                textboxusername.Focus();




            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            /*
            try
            {
                con.connectdb.Open();
                label7.Text = "Connection Ok";
                label7.ForeColor = Color.Red;
                con.connectdb.Close();
            }

            catch
            {
                label7.Text = "Error";
                label7.ForeColor = Color.Blue;
            }*/
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}