﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace EpupilSplashScreen
{
    class UserLoginClass
    {
        public MySqlConnection connectdb;

        public UserLoginClass()
        {
            string hostname = "localhost";
            string database = "logindb";
            string username = "root";
            string password = "root";
            string port = "3306";
            string connection_string = "datasource=" + hostname + "; database= " + database + ";port=" + port + "; username=" + username + "; password=" + password + "; SslMode=none";


            connectdb = new MySqlConnection(connection_string);
        }
    }


}
