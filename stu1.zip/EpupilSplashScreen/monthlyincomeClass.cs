﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EpupilSplashScreen
{
    class monthlyincomeClass

    {
        DBconnect connect = new DBconnect();

        public void totalIncome()
        {
            MySqlCommand command = new MySqlCommand("SELECT * FROM `student`", connect.getconnection);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            generatIncomeDoc(table);
        }

        public void generatIncomeDoc(DataTable dataTable)
        {
            string fileName = @"C:\Users\USER\Desktop\Income.txt";

            try
            {
                // Check if file already exists. If yes, delete it.     
                if (File.Exists(fileName))
                {
                    File.Delete(fileName);
                }

                // Create a new file     
                using (FileStream fs = File.Create(fileName))
                {
                    int monthlyIncomeTotal = 0;
                    int monthlyTobeReceivedIncomeTotal = 0;

                    // Add some text to file
                    foreach (DataRow row in dataTable.Rows)
                    {
                        monthlyIncomeTotal = row.Field<int>(9) + monthlyIncomeTotal;
                        monthlyTobeReceivedIncomeTotal = row.Field<int>(10) + monthlyTobeReceivedIncomeTotal;
                    }

                    Byte[] customer = new UTF8Encoding(true).GetBytes("Monthly income:");
                    fs.Write(customer, 0, customer.Length);
                    byte[] colen = new UTF8Encoding(true).GetBytes(monthlyIncomeTotal.ToString());
                    fs.Write(colen, 0, colen.Length);
                    byte[] newLine = new UTF8Encoding(true).GetBytes("\r\n");
                    fs.Write(newLine, 0, newLine.Length);
                    byte[] stdPaid = new UTF8Encoding(true).GetBytes("Income to be Received ::");
                    fs.Write(stdPaid, 0, stdPaid.Length);
                    byte[] received = new UTF8Encoding(true).GetBytes(monthlyTobeReceivedIncomeTotal.ToString());
                    fs.Write(received, 0, received.Length);

                }

                // Open the stream and read it back.    
                using (StreamReader sr = File.OpenText(fileName))
                {
                    string s = "";
                    while ((s = sr.ReadLine()) != null)
                    {
                        Console.WriteLine(s);
                    }
                }
            }
            catch (Exception Ex)
            {
                Console.WriteLine(Ex.ToString());
            }

        }
    }

}
