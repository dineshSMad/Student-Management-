﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;


namespace EpupilSplashScreen
{
    class SubjectClass
    {
        DBconnect connect = new DBconnect();

        public bool insertcourse(string curs, string curids, string ss1, string ee1, string aa1, string ll1,
            string llh1, string ss2, string ee2, string aa2, string ll2, string llh2)
        {
            MySqlCommand command = new MySqlCommand("INSERT INTO `course`(`Course`, `CourseID`, `Subject 01`, `Exam 01`," +
                " `Assig. 01`, `Lecturer 01`, `Lec.hours 01`, `Subject 02`, `Exam 02`, `Assig. 02`, `Lecturer 02`, `Lec.hours 02`) VALUES (@cu,@cid, @s1,@e1,@a1,@l1,@lh1, @s2,@e2,@a2,@l2,@lh2)", connect.getconnection);

            command.Parameters.Add("@cu", MySqlDbType.VarChar).Value = curs;
            command.Parameters.Add("@cid", MySqlDbType.VarChar).Value = curids;
            command.Parameters.Add("@s1", MySqlDbType.VarChar).Value = ss1;
            command.Parameters.Add("@e1", MySqlDbType.VarChar).Value = ee1;
            command.Parameters.Add("@a1", MySqlDbType.VarChar).Value = aa1;
            command.Parameters.Add("@l1", MySqlDbType.VarChar).Value = ll1;
            command.Parameters.Add("@lh1", MySqlDbType.VarChar).Value = llh1;
            command.Parameters.Add("@s2", MySqlDbType.VarChar).Value = ss2;
            command.Parameters.Add("@e2", MySqlDbType.VarChar).Value = ee2;
            command.Parameters.Add("@a2", MySqlDbType.VarChar).Value = aa2;
            command.Parameters.Add("@l2", MySqlDbType.VarChar).Value = ll2;
            command.Parameters.Add("@lh2", MySqlDbType.VarChar).Value = llh2;


            connect.openConnect();
            if (command.ExecuteNonQuery() == 1)
            {
                connect.closeconnect();
                return true;
            }
            else
            {
                connect.closeconnect();
                return false;
            }

        }

        //table
        public DataTable getcourslist()
        {

            MySqlCommand command = new MySqlCommand("SELECT * FROM `course`", connect.getconnection);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }


        // for the combo box
        public DataTable gettocourscombo(MySqlCommand command)
        {

            command.Connection = connect.getconnection;
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }







        public bool updatetcourse(string curs, string curids, string ss1, string ee1, string aa1, string ll1,
          string llh1, string ss2, string ee2, string aa2, string ll2, string llh2)
        {
            MySqlCommand command = new MySqlCommand("UPDATE INTO  `course`SET  `CourseID`=@cid, `Subject 01`=@s1, `Exam 01`=@e1, `Assig. 01`=@a1, `Lecturer 01`=@l1, `Lec.hours 01`=@lh1, `Subject 02`=@s2, `Exam 02`=@e2, `Assig. 02`=@a2, `Lecturer 02`=@l2, `Lec.hours 02`=@lh2  WHERE `Course`=@cu,", connect.getconnection);

            command.Parameters.Add("@cu", MySqlDbType.VarChar).Value = curs;
            command.Parameters.Add("@cid", MySqlDbType.VarChar).Value = curids;
            command.Parameters.Add("@s1", MySqlDbType.VarChar).Value = ss1;
            command.Parameters.Add("@e1", MySqlDbType.VarChar).Value = ee1;
            command.Parameters.Add("@a1", MySqlDbType.VarChar).Value = aa1;
            command.Parameters.Add("@l1", MySqlDbType.VarChar).Value = ll1;
            command.Parameters.Add("@lh1", MySqlDbType.VarChar).Value = llh1;
            command.Parameters.Add("@s2", MySqlDbType.VarChar).Value = ss2;
            command.Parameters.Add("@e2", MySqlDbType.VarChar).Value = ee2;
            command.Parameters.Add("@a2", MySqlDbType.VarChar).Value = aa2;
            command.Parameters.Add("@l2", MySqlDbType.VarChar).Value = ll2;
            command.Parameters.Add("@lh2", MySqlDbType.VarChar).Value = llh2;


            connect.openConnect();
            if (command.ExecuteNonQuery() == 1)
            {
                connect.closeconnect();
                return true;
            }
            else
            {
                connect.closeconnect();
                return false;
            }

        }

        public bool deletecourse(string curs)
        {
            MySqlCommand command = new MySqlCommand("DELETE FROM `course` WHERE `Course`=@cu", connect.getconnection);

            //@cu


            command.Parameters.Add("@cu", MySqlDbType.VarChar).Value = curs;


            connect.openConnect();
            if (command.ExecuteNonQuery() == 1)
            {
                connect.closeconnect();
                return true;
            }
            else
            {
                connect.closeconnect();
                return false;
            }


        }

    }

}
