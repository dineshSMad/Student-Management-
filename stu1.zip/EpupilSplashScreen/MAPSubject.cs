﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace EpupilSplashScreen
{
    public partial class MAPSubject : Form
    {

        mapsubClass sul = new mapsubClass();

        ClassClass cls = new ClassClass();

        SubjectClass sub = new SubjectClass();

        public MAPSubject()
        {
            InitializeComponent();
        }
       

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void MAPSubject_Load(object sender, EventArgs e)
        {
            showTable();

            //populate class combobox 
            comboBoxclass.DataSource = cls.getClasslistforcombo(new MySqlCommand("SELECT * FROM `class` "));
            comboBoxclass.DisplayMember = "ClassName";
            comboBoxclass.ValueMember = "ClassName";


            //populate subject combobox 
           comboBox3subject.DataSource = sub.gettocourscombo (new MySqlCommand("SELECT * FROM `course` "));
           comboBox3subject.DisplayMember = "Subject 01";
           comboBox3subject.ValueMember = "Subject 01";
          


        }
        public void showTable()
        {
            DataGridView1.DataSource = sul.getclasslist(); //student list
        }

        private void button1_Click(object sender, EventArgs e)//save button 
        {
            DateTime toda = dateTimePicker1.Value;
            string su = comboBox3subject.Text;
            string ti = comboBox1time.Text;
            string cla = comboBoxclass.Text;

            if (verify())
            {
                {
                    if (sul.insertclass(toda, su, ti, cla))

                    {
                        showTable();
                        MessageBox.Show("New Class Added", "Add Class", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }

            else
            {
                MessageBox.Show("Empty Field", "Add Class", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        //to verify
        bool verify()
        {
            if ((comboBox3subject.Text == "") || (comboBox1time.Text == "") ||
            (comboBoxclass.Text == ""))
            {
                return false;
            }
            else
                return true;
        }

        private void button3_Click(object sender, EventArgs e)//edite button 
        {
            DateTime toda = dateTimePicker1.Value;
            string su = comboBox3subject.Text;
            string ti = comboBox1time.Text;
            string cla = comboBoxclass.Text;

            if (verify())
            {
                {
                    if (sul.insertclass(toda, su, ti, cla))

                    {
                        showTable();
                        MessageBox.Show("Class Editted", "Add Class", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }

            else
            {
                MessageBox.Show("Empty Field", "Class Editted", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button2_Click(object sender, EventArgs e)//clear button 
        {
            dateTimePicker1.Value = DateTime.Now;
            comboBox3subject.Text = "";
            comboBox1time.Text = "";
            comboBoxclass.Text = "";
        }

        private void DataGridView1_Click(object sender, EventArgs e) //get data from the data base to boxes
        {
            dateTimePicker1.Value = (DateTime)DataGridView1.CurrentRow.Cells[0].Value;
            comboBox3subject.Text = DataGridView1.CurrentRow.Cells[1].Value.ToString();
            comboBox1time.Text = DataGridView1.CurrentRow.Cells[2].Value.ToString();
            comboBoxclass.Text = DataGridView1.CurrentRow.Cells[3].Value.ToString();

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            DataGridView1.DataSource = sul.searchsul(textBox1search.Text);

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            //remove the selected class            

            string su = comboBox3subject.Text;


            //Show a confirmation message before delete the student
            if (MessageBox.Show("want to remove this class", "Remove class", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (sul.deleteclass(su))
                {
                    showTable();
                    MessageBox.Show("class Removed", "Remove class", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
