﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;


namespace EpupilSplashScreen
{
    class StaffClass
    {
        StaffDb connect = new StaffDb ();
        public bool insertstaff(string ID, string at, string fn, string ln, DateTime dob, string phone, string address,string design )
        {
            MySqlCommand command = new MySqlCommand("INSERT INTO `staff`(`User ID`, `Account Type`, `First Name`, `Last Name`, `DoB`, `Phone`, `Address`, `Designation`) VALUES (@rn, @at, @fn, @ln, @dob, @phn, @address,@jb)", connect.getconnection);



            //`User ID`, `Account Type`, `First Name`, `Last Name`, `DoB`, `Phone`, `Address`, `Designation`



            command.Parameters.Add("@rn", MySqlDbType.VarChar).Value = ID;
            command.Parameters.Add("@at", MySqlDbType.VarChar).Value = at;
            command.Parameters.Add("@fn", MySqlDbType.VarChar).Value = fn;
            command.Parameters.Add("@ln", MySqlDbType.VarChar).Value = ln;
            command.Parameters.Add("@dob", MySqlDbType.Date).Value = dob;
            command.Parameters.Add("@phn", MySqlDbType.VarChar).Value = phone;
            command.Parameters.Add("@address", MySqlDbType.VarChar).Value = address;
            command.Parameters.Add("@jb", MySqlDbType.VarChar).Value = design;
            
            connect.openConnect();
            if (command.ExecuteNonQuery() == 1)
            {
                connect.closeconnect();
                return true;
            }
            else
            {
                connect.closeconnect();
                return false;
            }
        }
        // Create a function to execute the count query(total)
        public string Count1(string query)
        {
            MySqlCommand command = new MySqlCommand(query, connect.getconnection);
            connect.openConnect();
            string count1 = command.ExecuteScalar().ToString();
            connect.closeconnect();
            return count1;
        }

        // to get the total staff memebers 
        public string totalstaff()
        {
            return Count1("SELECT COUNT(*) FROM staff");
        }


        //to search student (first name, last name)
        public DataTable searchstaff (string searchdata)
        {
            MySqlCommand command = new MySqlCommand("SELECT * FROM `staff` WHERE CONCAT(`First Name`,`Last Name`) LIKE '%" + searchdata + "%'", connect.getconnection);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }

        //edite student 
        public bool editestaff(string ID, string at, string fn, string ln, DateTime dob, string phone, string address, string design)
        {
            MySqlCommand command = new MySqlCommand("UPDATE INTO `staff` SET  `Account Type`=@at, `First Name`= @fn, `Last Name`=@ln, `DoB`=@dob, `Phone`=@phn, `Address`=@address, `Designation`=@jb WHERE `User ID`=@rn", connect.getconnection);

            //`User ID`, `Account Type`, `First Name`, `Last Name`, `DoB`, `Phone`, `Address`, `Designation`

            command.Parameters.Add("@rn", MySqlDbType.VarChar).Value = ID;
            command.Parameters.Add("@at", MySqlDbType.VarChar).Value = at;
            command.Parameters.Add("@fn", MySqlDbType.VarChar).Value = fn;
            command.Parameters.Add("@ln", MySqlDbType.VarChar).Value = ln;
            command.Parameters.Add("@dob", MySqlDbType.Date).Value = dob;
            command.Parameters.Add("@phn", MySqlDbType.VarChar).Value = phone;
            command.Parameters.Add("@address", MySqlDbType.VarChar).Value = address;
            command.Parameters.Add("@jb", MySqlDbType.VarChar).Value = design;

            connect.openConnect();
            if (command.ExecuteNonQuery() == 1)
            {
                connect.closeconnect();
                return true;
            }
            else
            {
                connect.closeconnect();
                return false;
            }
        }

        //delete staff memeber
        public bool deletestaff(string fn)
        {
            MySqlCommand command = new MySqlCommand("DELETE FROM `staff` WHERE `User ID`=@rn", connect.getconnection);

            //`User ID`, 

            command.Parameters.Add("@rn", MySqlDbType.VarChar).Value = fn;
            

            connect.openConnect();
            if (command.ExecuteNonQuery() == 1)
            {
                connect.closeconnect();
                return true;
            }
            else
            {
                connect.closeconnect();
                return false;
            }
        }
        //table
        public DataTable getstafflist()
        {

            MySqlCommand command = new MySqlCommand("SELECT * FROM `staff`", connect.getconnection);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }



    }
}

