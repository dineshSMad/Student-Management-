﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;
using EpupilSplashScreen;

namespace EpupilSplashScreen
{
    class Accounts : UserLoginClass
    {

        public string username { get; set; }

        public string password { get; set; }

        public string fullname { get; set; }


        public bool validate_user()
        {
        

        bool check = false;

            connectdb.Open();

            MySqlDataReader rd;

            using (var cmd = new MySqlCommand())
            {
                cmd.CommandText = "SELECT* FROM users where User_Name=@user AND User_Password=@password";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = connectdb;

                cmd.Parameters.Add("@user", MySqlDbType.VarChar).Value = username;
                cmd.Parameters.Add("password", MySqlDbType.VarChar).Value = password;

                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    check = true;
                    fullname = rd.GetString("Name");
                }

                connectdb.Close();
            }

        return check;

          }

    }








}

