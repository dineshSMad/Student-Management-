﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EpupilSplashScreen
{
    public partial class FormClass : Form
    {
        ClassClass oneclass = new ClassClass();

        public FormClass()
        {
            InitializeComponent();
        }

        private void FormClass_Load(object sender, EventArgs e)
        {
            showTable();
    }

        //student list

      public void showTable()
       {
           DataGridViewclass.DataSource = oneclass.getClasslist();
        }


    private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)  //to add 
        {
            string ClassNumber = textBox2Cnum.Text;
            string ClassName = textBoxClassName.Text;
            string seat = textBox6seat.Text;
            string AC = airradiobAC.Checked ? "AC" : "NONAC";
               
            if (verify())
            {
                {
                    if (oneclass.insertclass(ClassNumber, ClassName, seat, AC))

                    {
                        showTable();
                        MessageBox.Show("New Class Added", "Add Class", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }

            }

            else
            {
                MessageBox.Show("Empty Field", "Add Class", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }


            //to verify
            bool verify()
            {
                if ((textBox2Cnum.Text == "") || (textBoxClassName.Text== "") ||
                (textBox6seat.Text == ""))
                {
                    return false;
                }
                else
                    return true;
            }

        }

           
     private void button2delete_Click(object sender, EventArgs e)       //clear  Button
              {
            textBox2Cnum.Clear();
            textBoxClassName.Clear();
            textBox6seat.Clear();
            radioButtonnonac.Checked = false;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)//edite button 
        {
            string ClassNumber = textBox2Cnum.Text;
            string ClassName = textBoxClassName.Text;
            string seat = textBox6seat.Text;
            string AC = airradiobAC.Checked ? "AC" : "NONAC";

            if (verify())
            {
                {
                    if (oneclass.insertclass(ClassNumber, ClassName, seat, AC))

                    {
                        showTable();
                        MessageBox.Show("Class Edited", "Add Edited", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }

            }

            else
            {
                MessageBox.Show("Empty Field", "Add Edited", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }


            //to verify
            bool verify()
            {
                if ((textBox2Cnum.Text == "") || (textBoxClassName.Text == "") ||
                (textBox6seat.Text == ""))
                {
                    return false;
                }
                else
                    return true;
            }

        }

        private void button1_Click_1(object sender, EventArgs e)//delete button 
        {
            string ClassNumber = textBox2Cnum.Text;


            //Show a confirmation message before delete the class
            if (MessageBox.Show("want to remove this class", "Remove class", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (oneclass.deleteclass(ClassNumber))
                {
                    showTable();
                    MessageBox.Show("Class Removed", "Remove Class", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
            }
        }

        private void DataGridViewclass_Click(object sender, EventArgs e) // click get data back fro data base 
        {

            textBox2Cnum.Text = DataGridViewclass.CurrentRow.Cells[0].Value.ToString();
            textBoxClassName.Text= DataGridViewclass.CurrentRow.Cells[1].Value.ToString();
            textBox6seat.Text= DataGridViewclass.CurrentRow.Cells[2].Value.ToString();
            if (DataGridViewclass.CurrentRow.Cells[3].Value.ToString() == "AC") airradiobAC.Checked = true; else radioButtonnonac.Checked = true;


        }
    }
}
